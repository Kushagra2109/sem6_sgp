window._config = {
    cognito: {
        userPoolId: 'ap-south-1_8f6D0LI5g', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: 'crgrg1v40odp5tq2v4jbia2lt', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'ap-south-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: '' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod,
    }
};
